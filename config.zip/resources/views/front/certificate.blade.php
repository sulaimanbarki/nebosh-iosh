





<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/main.css') }}">

<div style="position:relative; top:10px; bottom:10px; left:10px; right:10px">
    <img src="{{ asset('images/NeboshLogo.jpg') }}" height="200" width="200" style="display:block; margin-left:auto; margin-right:auto" />
    
   <h2 style="text-align:center">THIS IS A VALID CERTIFICATE</h2>
   <hr />
    <div>
        <h4>PLEASE ENSURE THAT THE DETAILS ON THE PRINTED CERTIFICATE MATCH THE VERIFIED DETAILS BELOW:</h4>
        <hr />
        <dl class="dl-horizontal">

            <dd>
                <strong>Learner Name: </strong>Zulqarnain Haider
            </dd>

            <dd>
                <strong>Learner Number: </strong>00522690
            </dd>

                <dd>
                    <strong>Qualification Name: </strong>NEBOSH International General Certificate in Occupational Health and Safety
                </dd>


                <dd>
                    <strong>Qualification Grade: </strong>CREDIT
                </dd>
            
                <dd>
                    <strong>SQA Reference: </strong>R630 04
                </dd>

            <dd>
                <strong>Date Awarded: </strong>14/06/2021
            </dd>

            <dd>
                <strong>Certificate log Number: </strong>00522690/1225541
            </dd>

        </dl>
    </div>
</div>